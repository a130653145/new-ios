//
//  ????.swift
//  WIN
//
//  Created by User17 on 2020/10/14.
//

// Calendar.current.component(.year, from: Date()) this year
import SwiftUI
struct ten_years_later: View {
    @State private var date = Date()
    @State private var year: Double = Double(Calendar.current.component(.year, from: Date()))
    
    var body: some View {
        
   
            
            
          
            VStack{
                
                if year==2020
                {
                    Image("GG")
                        .resizable()
                        .scaledToFit()
                }
                else if year==2021
                {
                    Image("QAQ")
                        .resizable()
                        .scaledToFit()
                }
                else if year==2022
                {
                    Image("oao")
                        .resizable()
                        .scaledToFit()
                }
                else if year==2023
                {
                    Image("卡比")
                        .resizable()
                        .scaledToFit()
                }
                else if year==2024
                {
                    Image("卡比1")
                        .resizable()
                        .scaledToFit()

                }
                else if year==2025
                {
                    Image("卡比2")
                        .resizable()
                        .scaledToFit()

                }
                else if year==2026
                {
                    Image("卡比3")
                        .resizable()
                        .scaledToFit()

                }
                else if year==2027
                {
                    Image("卡比4")
                        .resizable()
                        .scaledToFit()

                }
                else if year==2028
                {
                    Image("卡比5")
                        .resizable()
                        .scaledToFit()

                }
                else if year==2029
                {
                    Image("卡比6")
                        .resizable()
                        .scaledToFit()


                }
                else if year==2030
                {
                    Image("卡比7")
                        .resizable()
                        .scaledToFit()

                }
                
                
                Text("\(year, specifier: "%g") 年")
                Slider(value: self.$year
                    
                , in: Double(Calendar.current.component(.year, from: Date()))...Double(Calendar.current.component(.year, from: Date()))+10        , step: 1){
                    Text("")
                }
                
                 
  
            }
        
    }
}
struct ten_years_later_Previews    : PreviewProvider {
    static var previews: some View {
        
           ten_years_later()
            
        
    }
}
