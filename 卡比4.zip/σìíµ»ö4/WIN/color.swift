//
//  color.swift
//  parentUITests
//
//  Created by User17 on 2020/10/30.
//


import SwiftUI


struct color: View {
    @State private var bgColor = Color.white

    var body: some View {
        VStack {
            ColorPicker("Set the background color", selection: $bgColor)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(bgColor)
    }
}

struct color_Previews: PreviewProvider {
    static var previews: some View {
        color()
    }
}
