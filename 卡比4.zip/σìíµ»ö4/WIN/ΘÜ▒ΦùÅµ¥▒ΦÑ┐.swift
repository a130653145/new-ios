//
//  test.swift
//  WIN
//
//  Created by User17 on 2020/10/21.
//

import SwiftUI

struct test: View {

    @State private var buyPhone = true
    @State private var selectPhone = "iPhone 11 Pro Max"
    
    let phones = ["iPhone 11 Pro Max", "iPhone 11 Pro", "iPhone 11"]
    var body: some View {
        Form {
            Toggle("開發 iOS App 要買 iPhone 嗎", isOn: $buyPhone)
            if buyPhone {
                VStack(alignment: .leading) {
                    Text("我要買")
                    Picker("買 iPhone", selection: $selectPhone) {
                        ForEach(phones, id: \.self) { (phone) in
                            Text(phone)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    
                    if selectPhone == "iPhone 11 Pro Max"
                    {
                        Image("iphone_11_pro_max")
                    }
                    else if selectPhone == "iPhone 11 Pro"
                    {
                        Image("iphone_11_pro")
                    }
                    
                    else if selectPhone == "iPhone 11"
                    {
                        Image("iphone_11")
                    }
                    
                    List {
                               Text("this is list in form")
                               Text("First name")
                               Text("Last name")
                               Button(action: {
                                   
                               }) {
                                   HStack {
                                       Image(systemName: "plus.circle.fill")
                                       Text("add phone")
                                   }
                               }
                           }
                }
                
                List {
                           Text("this is list")
                           Text("First name")
                           Text("Last name")
                           Button(action: {
                               
                           }) {
                               HStack {
                                   Image(systemName: "plus.circle.fill")
                                   Text("add phone")
                               }
                           }
                       }
                
            }
        }
    }
}


struct test_Previews: PreviewProvider {
    static var previews: some View {
        test()
    }
}
