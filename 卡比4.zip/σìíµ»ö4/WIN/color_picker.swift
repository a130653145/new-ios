
import SwiftUI

struct color_picker: View {
    @State private var bgColor = Color.white

    var body: some View {
        VStack {
            ColorPicker("Set the background color", selection: $bgColor)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(bgColor)
    }
}

struct color_picker_Previews: PreviewProvider {
    static var previews: some View {
color_picker()
        
    }
}
