//
//  File.swift
//  WIN
//
//  Created by User17 on 2020/10/30.
//
import SwiftUI

struct Role {
     let name: String
     let gender: String
 }
extension String: Identifiable {
    public var id: String { self }
}


struct Picker1: View {
    var roles = ["李白", "李嘉誠", "彼得潘", "奇妙仙子"]
       @State private var selectedName = "李白"
    var roles1 = ["李白", "李嘉誠", "彼得潘", "奇妙仙子"]
       @State private var selectedName1 = "李白"
    
       var body: some View {
          VStack {
            ScrollView{
                 Picker(selection: $selectedName, label: Text("選擇角色")) {
                    ForEach(roles, id: \.self) { (role) in
                       Text(role)
                    }
                 }
                 .frame(width: 300, height: 300)
                Text("要是能重來，我要選\(selectedName)")
                
                
                
                Picker(selection: $selectedName1, label: Text("選擇角色")) {
                    //用到 extension String:Identifiable{public var id: String { self }}
                
                            ForEach(roles1) { (role1) in
                               Text(role1)
                            }
                         }
                .frame(width: 300, height: 300)
                //.pickerStyle(SegmentedPickerStyle())
                Text("要是能重來，我要選\(selectedName1)")
                
                
                
                Picker(selection: $selectedName1, label: Text("選擇角色")) {
                    //用到 extension String:Identifiable{public var id: String { self }}
                
                            ForEach(roles1) { (role1) in
                               Text(role1)
                            }
                         }
                .frame(width: 300, height: 300)
                .pickerStyle(SegmentedPickerStyle())
                Text("要是能重來，我要選\(selectedName1)")
            }
          }
       }

}



   

struct Picker1_Previews: PreviewProvider {
    static var previews: some View {
        Picker1()
        
    }
}
