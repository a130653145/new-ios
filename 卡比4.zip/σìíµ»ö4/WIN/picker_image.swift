//
//  picker-image.swift
//  WIN
//
//  Created by User17 on 2020/10/30.
//
import SwiftUI

struct picker_image: View {
   var images = ["sun.max.fill", "cloud.rain.fill", "cloud.sun.rain.fill"]
   var names = ["晴天", "雨天", "又晴又雨"]
    
   @State private var selectedIndex = 0
    
var body: some View {
      VStack {
         Picker(selection: $selectedIndex, label: Text("選擇天氣")) {
            ForEach(images.indices) { (index) in
               HStack {
                  Image(systemName: images[index])
                     .foregroundColor(.blue)
                  Text(names[index])
                     .foregroundColor(.blue)
               }
            }
         }
         Image(systemName: images[selectedIndex])
            .resizable()
            .scaledToFit()
      }
   }
}


struct picker_image_Previews: PreviewProvider {
    static var previews: some View {
        picker_image()
        
    }
}
