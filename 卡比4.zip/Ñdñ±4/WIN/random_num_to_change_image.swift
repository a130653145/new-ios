//
//  ㄙㄛrain.swift
//  WIN
//
//  Created by User17 on 2020/10/7.
//

import SwiftUI


struct random_num_to_change_image: View {
  
@State var random_num = 3
    
    var body: some View {
      VStack {
        
        if random_num==1 {
           Image("QAQ")
              .resizable()
              .frame(width: 100, height: 100)
           Text("QAQ")
        }
        else if random_num==2
        {
           Image("GG")
              .resizable()
              .frame(width: 100, height: 100)
           Text("GG")
        }
        else if random_num==3
        {
           Image("卡比")
              .resizable()
              .frame(width: 100, height: 100)
           Text("ＸＤ")
        }
        
        else if random_num==4
        {
           Image("oao")
              .resizable()
              .frame(width: 100, height: 100)
           Text("PAP")
        }
        else if random_num==5
        {
           Image("卡比1")
              .resizable()
              .frame(width: 100, height: 100)
           Text("666")
        }
        else if random_num==6
        {
           Image("卡比2")
              .resizable()
              .frame(width: 100, height: 100)
           Text("P")
        }
        else if random_num==7
        {
           Image("卡比3")
              .resizable()
              .frame(width: 100, height: 100)
           Text("888")
        }
        else if random_num==8
        {
           Image("卡比4")
              .resizable()
              .frame(width: 100, height: 100)
           Text("888")
        }
        else if random_num==9
        {
           Image("卡比5")
              .resizable()
              .frame(width: 100, height: 100)
           Text("555")
        }
        else if random_num==10
        {
           Image("卡比6")
              .resizable()
              .frame(width: 100, height: 100)
           Text("123456")
        }
        
        
        Button("隨機一張?") {
        random_num = Int.random(in:1...10)
       }
        Text("第\(Int(random_num))張")
   }
}

}

struct random_num_to_change_image_Previews: PreviewProvider {
    static var previews: some View {
        random_num_to_change_image()
    }
}
