//
//  picker_image_2.swift
//  WIN
//
//  Created by User17 on 2020/10/30.
//

import SwiftUI


struct picker_image_2: View {
   @State private var loveAge = 2
    @State private var year = 0
   var body: some View {
      VStack {
        
        
        
        
         Picker("age", selection: $loveAge) {
            ForEach(18 ..< 100) { (age) in
               Text("\(age)歲")
            }
         }
        
         Text("適合談戀愛的年紀: \(18 + loveAge) 歲")
        Text("實際時間: \(loveAge) 年")
        
        if year+2020==2020
        {
            Image("GG")
                .resizable()
                .scaledToFit()
        }
        else if year==1
        {
            Image("QAQ")
                .resizable()
                .scaledToFit()
        }
        else if year==2
        {
            Image("oao")
                .resizable()
                .scaledToFit()
        }
        else if year==3
        {
            Image("卡比")
                .resizable()
                .scaledToFit()
        }
        else if year==4
        {
            Image("卡比1")
                .resizable()
                .scaledToFit()

        }
        else if year==5
        {
            Image("卡比2")
                .resizable()
                .scaledToFit()

        }
        else if year==6
        {
            Image("卡比3")
                .resizable()
                .scaledToFit()

        }
        else if year==7
        {
            Image("卡比4")
                .resizable()
                .scaledToFit()

        }
        else if year==8
        {
            Image("卡比5")
                .resizable()
                .scaledToFit()

        }
        else if year==9
        {
            Image("卡比6")
                .resizable()
                .scaledToFit()


        }
        else if year==10
        {
            Image("卡比7")
                .resizable()
                .scaledToFit()

        }
        
        Picker("age", selection: $year) {
           ForEach(2020 ..< 2031) { (years) in
              Text("\(years)年")
            
           }
           
            
        }
        
        
        
        
      }
   }
}

struct picker_image_2_Previews: PreviewProvider {
    static var previews: some View {
        picker_image_2()
    }
}
