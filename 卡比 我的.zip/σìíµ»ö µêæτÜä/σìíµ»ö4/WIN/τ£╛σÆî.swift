



import SwiftUI




struct mix: View {
    
 
    
    @State private var buyPhone = false
    
    @State private var scale: CGFloat = 1
   
  
    
    @State private var red1: Double = 0.5
    
    @State private var green1: Double = 1
    
    @State private var blue1: Double = 1
    
    @State private var brightnessAmount: Double = 0

    @State private var corner: CGFloat = 0
    
    
    
    @State private var blur: CGFloat = 0
    
    @State private var saturation1: Double = 1.0
    
    @State private var x1: CGFloat = 0
    
    @State private var y1: CGFloat = 0
   
    @State private var z1: CGFloat = 0
    
    @State private var date = Date()
    @State private var year: Double = Double(Calendar.current.component(.year, from: Date()))
    
    @State private var corner1 = 0

    var body: some View {
        
        var components = DateComponents()
        components.calendar = Calendar.current
        components.year = Calendar.current.component(.year, from: Date())//=今年
        let startDate = components.date!
        components.year = Calendar.current.component(.year, from: Date())+10
        let endDate = components.date!
        
        return
            
            List {
                Toggle("開發 iOS App 要買 iPhone 嗎(按完後不知為何會隱型 但還能按 被background遮掉)", isOn: $buyPhone).foregroundColor(.blue)
                    .background(Color(red: red1, green: green1, blue:blue1).frame(width:999, height:  100))
                if buyPhone {
                
                    VStack {
                        
                       
                        
                   
                        Group{
                        
                        
                        if year==2020
                        {
                            
                            
                            
                            
                            Image("GG")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                                
                           //     .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                            
                        }
                        else if year==2021
                        {
                            
                            
                            Image("QAQ")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                                //.background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                            
                        }
                        else if year==2022
                        {
                            Image("oao")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                                //.background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                            
                        }
                        else if year==2023
                        {
                            Image("卡比")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                               // .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                            
                        }
                        else if year==2024
                        {
                            Image("卡比1")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                               // .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if year==2025
                        {
                            Image("卡比2")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                               // .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if year==2026
                        {
                            Image("卡比3")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                                //.background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if year==2027
                        {
                            Image("卡比4")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                                //.background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if year==2028
                        {
                            Image("卡比5")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                              //  .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                        else if year==2029
                        {
                            Image("卡比6")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                               // .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                            
                        }
                        else if year==2030
                        {
                            Image("卡比7")
                                .resizable()
                                .scaledToFit()
                                .brightness(brightnessAmount)
                                .scaleEffect(scale)
                                .cornerRadius(CGFloat(corner1))
                                .saturation(saturation1)
                                .blur(radius: blur)
                                .rotation3DEffect(Angle(degrees: 45), axis: (x: x1, y: y1, z: z1))
                             //   .background(Color(red: red1, green: green1, blue:blue1).frame(width:9999, height:  9999))
                        }
                    
                    }
                    
                   
                    
                       
                    
                    

                    
                    
                   
                    
                    ScrollView{
                             VStack {
                                
                               
                                
                                
                        
                                Group
                                {
                                    Text("隨時間變化的圖片")
                                    Text("設定時間\(year, specifier: "%g") 年")
                                    Slider(value: Binding(get: {
                                        self.year
                                    }, set: {
                                        self.year = $0
                                        var components = DateComponents()
                                        components.calendar = Calendar.current
                                        components.year = Int(self.year)
                                        self.date = components.date!
                                    }), in: Double(Calendar.current.component(.year, from: Date()))...Double(Calendar.current.component(.year, from: Date()))+10        , step: 1)
                                    DatePicker(selection: Binding(get: {
                                        self.date
                                    }, set: {
                                        self.date = $0
                                        self.year = Double(Calendar.current.component(.year, from: self.date))
                                    }), in: startDate...endDate, displayedComponents: .date) {
                                        Text("")
                                    }
                                }
                                
                                
                                
                                
                                
                            Group{
                                Text("亮度")
                                
                                Slider(value: $brightnessAmount, in: 0...1, minimumValueLabel: Image(systemName: "sun.max.fill").imageScale(.small), maximumValueLabel: Image(systemName: "sun.max.fill").imageScale(.large))
                        {
                        Text("")
                      }
                       
                    Text("大小: \(scale, specifier: "%.2f")")
                                Slider(value: $scale, in: 0...1, minimumValueLabel: Image(systemName: "sun.max.fill").imageScale(.small), maximumValueLabel: Image(systemName:     "sun.max.fill").imageScale(.large)) {
                        Text("")
                    }
                        
                    
                    
                    
                     
                                /*
                            Text("圖片們 第: \(Int(pictures)+1) 張")
                            Slider(value: $pictures, in: 0...11, step: 1)
                                */
                                
                                
                                Text("背景顏色: r:\(red1, specifier: "%.1f") g:\(green1, specifier: "%.1f") b:\(blue1, specifier: "%.1f")")
                                Slider(value: $red1, in: 0...1).accentColor(.red)
                                
                                Slider(value: $green1, in: 0...1).accentColor(.green)
                                Slider(value: $blue1, in: 0...1).accentColor(.blue)
                                
                                
                            }//group
                                
                                Group{
                                    //Text("邊緣圓滑度: \(Int(corner)) ")
                                    //Slider(value: $corner, in: 0...100)
                                    
                                    Text("邊緣圓滑度: \(corner1)")
                                    
                                    Picker("age", selection: $corner1) {
                                        ForEach(0 ..< 101) { (age) in
                                            Text("\(age)")
                                        }
                                    }
                                    
                                    
                                    
                                    
                                    Text("模糊度: \(Int(blur)) ")
                                    Slider(value: $blur, in: 0...50)
                                    
                                }
                                
                                Group{
                                    
                                    
                                    
                                    Text("3D選轉角度(45):x:\(x1, specifier: "%.1f")y:\(y1, specifier: "%.1f")z:\(z1, specifier: "%.1f")")
                                    

                                    Text("x")
                                    Slider(value: $x1, in: 0...1, step: 1)

                                    Text("y")
                                    Slider(value: $y1, in: 0...1, step: 1)

                                    Text("z")
                                    Slider(value: $z1, in: 0...1, step: 1)
                                    
                                    
                                    Text("飽和度:x:\(saturation1, specifier: "%.1f")")
                                    Slider(value: $saturation1, in: 0...3)
                                    
                                    
                                }
                               
                             }//VS
                    }//ScrollView
                    
                    
                    }
                    
               
                    
                    
                    
                    
                    
                
            }
            }
        
        
        
        
        
    }
}




struct mix_Previews: PreviewProvider {
    static var previews: some View {
        mix()
    }
}
